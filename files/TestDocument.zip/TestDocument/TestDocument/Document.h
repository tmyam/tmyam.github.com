//
//  Document.h
//  TestDocument
//
//  Created by zrshz on 14-2-20.
//  Copyright (c) 2014年 tmyam. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface Document : NSDocument

@end
