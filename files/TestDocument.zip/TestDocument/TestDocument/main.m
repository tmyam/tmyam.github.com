//
//  main.m
//  TestDocument
//
//  Created by zrshz on 14-2-20.
//  Copyright (c) 2014年 tmyam. All rights reserved.
//

#import <Cocoa/Cocoa.h>

int main(int argc, const char * argv[])
{
    return NSApplicationMain(argc, argv);
}
