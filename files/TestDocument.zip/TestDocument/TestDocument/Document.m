//
//  Document.m
//  TestDocument
//
//  Created by zrshz on 14-2-20.
//  Copyright (c) 2014年 tmyam. All rights reserved.
//

#import "Document.h"

@implementation Document

- (id)init
{
    self = [super init];
    if (self) {
        // Add your subclass-specific initialization here.
    }
    return self;
}

- (NSString *)windowNibName
{
    // Override returning the nib file name of the document
    // If you need to use a subclass of NSWindowController or if your document supports multiple NSWindowControllers, you should remove this method and override -makeWindowControllers instead.
    return @"Document";
}

- (void)windowControllerDidLoadNib:(NSWindowController *)aController
{
    [super windowControllerDidLoadNib:aController];
    // Add any code here that needs to be executed once the windowController has loaded the document's window.
}

+ (BOOL)autosavesInPlace
{
    return YES;
}











- (NSData *)dataOfType:(NSString *)typeName error:(NSError **)outError
{
    if ([typeName isEqualToString:@"com.tmyam.TestDocument.document"])
    {
        // TODO: 这里是具体的存储文件数据
        return [@"test" dataUsingEncoding:4];
    }
    else
    {
        if (outError)
        {
            *outError = [NSError errorWithDomain:@"TestDocumentErrorDomain"
                                            code:-1
                                        userInfo:@{NSLocalizedFailureReasonErrorKey:[NSString stringWithFormat:@"Unsupported data type: %@", typeName]}];
        }
    }
    return nil;
}

- (BOOL)readFromData:(NSData *)data ofType:(NSString *)typeName error:(NSError **)outError
{
    assert([typeName isEqualToString:@"com.tmyam.TestDocument.document"]);
    
    // TODO: 这里是具体的读取文件数据
 
    return YES;
}

@end
