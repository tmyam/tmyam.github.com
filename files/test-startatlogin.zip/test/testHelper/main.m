//
//  main.m
//  testHelper
//
//  Created by zrshz on 14-6-10.
//  Copyright (c) 2014年 tmyam. All rights reserved.
//

#import <Cocoa/Cocoa.h>

int main(int argc, const char * argv[])
{
    return NSApplicationMain(argc, argv);
}
