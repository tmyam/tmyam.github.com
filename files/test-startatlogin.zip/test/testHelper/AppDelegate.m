//
//  AppDelegate.m
//  testHelper
//
//  Created by zrshz on 14-6-10.
//  Copyright (c) 2014年 tmyam. All rights reserved.
//

#import "AppDelegate.h"

@implementation AppDelegate

- (void)applicationDidFinishLaunching:(NSNotification *)aNotification
{
    [self runMainApp:@"com.tmyam.test" appName:@"test"];
}

/** 运行开机自启动的app

 @param identifier 主app的标识符
 @param appName 主app的名称（在MacOS文件夹下的名称）
 */
- (void) runMainApp:(NSString*)identifier appName:(NSString*)appName
{
    // Check if main app is already running; if yes, do nothing and terminate helper app
    BOOL alreadyRunning = NO;
    NSArray *running = [[NSWorkspace sharedWorkspace] runningApplications];
    for (NSRunningApplication *app in running)
    {
        if ([[app bundleIdentifier] isEqualToString:identifier])
        {
            alreadyRunning = YES;
        }
    }
    if (!alreadyRunning)
    {
        NSString *path = [[NSBundle mainBundle] bundlePath];
        NSArray *p = [path pathComponents];
        NSMutableArray *pathComponents = [NSMutableArray arrayWithArray:p];
        [pathComponents removeLastObject];
        [pathComponents removeLastObject];
        [pathComponents removeLastObject];
        [pathComponents addObject:@"MacOS"];
        [pathComponents addObject:appName];
        NSString *newPath = [NSString pathWithComponents:pathComponents];
        [[NSWorkspace sharedWorkspace] launchApplication:newPath];
    }
    [NSApp terminate:nil];
}

@end
