//
//  TMStartAtLogin.m
//  test
//
//  Created by zrshz on 14-6-10.
//  Copyright (c) 2014年 tmyam. All rights reserved.
//

#import "TMStartAtLogin.h"
#import "StartAtLoginController.h"

@implementation TMStartAtLogin

+ (BOOL) isStartAtLogin
{
    StartAtLoginController* loginController = [[StartAtLoginController alloc]initWithIdentifier:@"com.tmyam.testHelper"];
    BOOL startedAtLogin = [loginController startAtLogin];
    [loginController release];
    return startedAtLogin;
}

+ (BOOL) setStartAtLogin:(BOOL)isStartLogin
{
    StartAtLoginController* loginController = [[StartAtLoginController alloc]initWithIdentifier:@"com.tmyam.testHelper"];
    loginController.startAtLogin = isStartLogin;
    BOOL result = loginController.enabled;
    [loginController release];
    return result;
}

@end
