//
//  AppDelegate.h
//  test
//
//  Created by zrshz on 14-6-10.
//  Copyright (c) 2014年 tmyam. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface AppDelegate : NSObject <NSApplicationDelegate>

@property (assign) IBOutlet NSWindow *window;


@property (nonatomic ,assign) NSNumber* startAtLogin;

@end
