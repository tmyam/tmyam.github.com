//
//  AppDelegate.m
//  test
//
//  Created by zrshz on 14-6-10.
//  Copyright (c) 2014年 tmyam. All rights reserved.
//

#import "AppDelegate.h"
#import "TMStartAtLogin.h"

@implementation AppDelegate

- (void)applicationDidFinishLaunching:(NSNotification *)aNotification
{
    
    
    
}


- (void) setStartAtLogin:(NSNumber *)startAtLogin
{
    [TMStartAtLogin setStartAtLogin:startAtLogin.boolValue];
}

- (NSNumber*) startAtLogin
{
    return @([TMStartAtLogin isStartAtLogin]);
}


@end
