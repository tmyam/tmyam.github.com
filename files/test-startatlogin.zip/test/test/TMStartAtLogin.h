//
//  TMStartAtLogin.h
//  test
//
//  Created by zrshz on 14-6-10.
//  Copyright (c) 2014年 tmyam. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface TMStartAtLogin : NSObject


/** 判断程序是否设置了开机自启动
 
 @return 是否设置了开机自启动
 */
+ (BOOL) isStartAtLogin;


/** 改变程序的开机自启动设置
 
 @param isStartLogin 是否开机自启动
 
 @return 修改是否成功
 */
+ (BOOL) setStartAtLogin:(BOOL)isStartLogin;


@end
