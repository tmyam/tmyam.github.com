#!/bin/bash

#配置项
APP_NAME="ToShowDesktop"
APP_LOW_VER="1.2.0"	
APP_ID="com.tmyam.$APP_NAME"
PLUGIN_NAME="MiniFinder"
PLUGIN_ID="com.tmyam.$PLUGIN_NAME"
SYS_CHANGE_VER="10.9"

#固定项
APP_PATH="/Applications/$APP_NAME.app"
APP_VER=""
APP_PLUGIN_PATH="/Applications/$APP_NAME.app/Contents/Resources"
PLUGIN_ZIP="$PLUGIN_NAME.zip"
PLUGIN_APP="$PLUGIN_NAME.app"
SYS_VER=""
ASSIST_SQL="/Library/Application Support/com.apple.TCC/TCC.db"

# 判断操作系统版本
SYS_VER=`sw_vers -productVersion`

if [[ "$SYS_VER" > "$SYS_CHANGE_VER" || "$SYS_VER" == "$SYS_CHANGE_VER" ]];then
   echo "yes"
else
RESULT=`exec osascript <<EOF
tell application "System Events"
set UI_enabled to UI elements enabled
end tell
return UI_enabled
EOF`

if [ "$RESULT" == "true" ];then
echo "yes"
else
exit 4
fi
fi

exit 0
